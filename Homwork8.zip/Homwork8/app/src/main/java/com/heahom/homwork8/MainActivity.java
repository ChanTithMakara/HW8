package com.heahom.homwork8;

import static android.widget.Toast.LENGTH_LONG;

import static com.heahom.homwork8.R.id.menuitem_about;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TabLayoutMediator.TabConfigurationStrategy {
    ViewPager2 viewPager2;
    TabLayout tabLayout;
    ArrayList<String> titles;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager2 = findViewById(R.id.viewPager2);
        tabLayout = findViewById(R.id.tabLayout);
        titles = new ArrayList<>();
        titles.add("Movies");
        titles.add("Events");
        titles.add("Tickets");
        setViewPageAdapter();
        new TabLayoutMediator(tabLayout, viewPager2, this).attach();
    }

    public void setViewPageAdapter() {
        ViewPage2Adapter viewPager2Adapter = new ViewPage2Adapter();
        ArrayList<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(new MovieFragment());
        fragmentList.add(new EventFragment());
        fragmentList.add(new TicketsFragment());
        viewPager2Adapter.setData(fragmentList);
        viewPager2.setAdapter(viewPager2Adapter); // Set the adapter to viewPager2
        ArrayList<Fragment> yourFragmentsList = new ArrayList<>();
        ActionTabsViewPagerAdapter adapter = new ActionTabsViewPagerAdapter(this, yourFragmentsList);
        viewPager2.setAdapter(adapter);

    }

    @Override
    public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
        tab.setText(titles.get(position));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuitem_search:
                Toast.makeText(this, getString(R.string.ui_menu_search), Toast.LENGTH_LONG).show();
                break;
            case R.id.menuitem_send:
                Toast.makeText(this, getString(R.string.ui_menu_send), Toast.LENGTH_LONG).show();
                break;
            case R.id.menuitem_add:
                Toast.makeText(this, getString(R.string.ui_menu_add), Toast.LENGTH_LONG).show();
                break;
            case R.id.menuitem_share:
                Toast.makeText(this, getString(R.string.ui_menu_share), Toast.LENGTH_LONG).show();
                break;
            case R.id.menuitem_feedback:
                Toast.makeText(this, getString(R.string.ui_menu_feedback), Toast.LENGTH_LONG).show();
                break;
            case menuitem_about:
                Toast.makeText(this, getString(R.string.ui_menu_about), Toast.LENGTH_LONG).show();
                break;
            case R.id.menuitem_quit:
                Toast.makeText(this, getString(R.string.ui_menu_quit), Toast.LENGTH_LONG).show();
                finish(); // Close the activity
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + item.getItemId());
        }
        return true;
    }

}