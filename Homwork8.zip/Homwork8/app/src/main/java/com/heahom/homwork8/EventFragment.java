package com.heahom.homwork8;

public class EventFragment extends androidx.fragment.app.Fragment {

}
